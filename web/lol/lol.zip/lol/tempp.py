a = "mIWltouQJGsBniKYvTxODAfbUcFzSpMwNCHEgrdLaPkyVRjXeqZh"
b="rgeQjPruaOnDaPeWrAaPnPrCnOrPaPnPjPrCaPrPnPrPaOrvaPndeOrAnOrPnOrOaPnPjPaOrPnPrPnPrPtPnPrAaPnBrnnsrnnBaPeOrCnPrOnCaPnOaPnPjPtPnAaPnPrP"
flag = "xiomara{A_PrO_Reverser_Want_Two_Beer}"
for i in range(len(flag)):
   if flag[i] not in ['{','}','_'] : 
     try:
       ind = a.index(flag[i])
       print "flag["+str(i)+"] ="+"a["+str(ind)+"];"
     except:
       ind = b.index(flag[i])
       print "flag["+str(i)+"] ="+"b["+str(ind)+"];"
   elif flag[i] == "{" :
       print "flag["+str(i)+"] ="+"'{' ;" 
   elif flag[i] == "}" :
     print "flag["+str(i)+"] ="+"'}' ;" 
   else: 
     print "flag["+str(i)+"] ="+"'_' ;" 
   
