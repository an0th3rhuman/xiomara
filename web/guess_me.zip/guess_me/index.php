
<?php

$user_pass = $status = $lol = "";
$err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if( empty($_POST["passwd"])  ){
      $err = "Error : Field is mandatory";
  }else{

      $user_pass = sanitize($_POST["passwd"]);
      $status = 1;

      if($status == 1){
        switch($user_pass){
          case 'i':
            $lol = "you guessed one !";
            break;
          case 'k':
            $lol = "you guessed one !";
            break;
          case 'n':
            $lol = "you guessed one !";
            break;
          case 'o':
            $lol = "You guessed one or may be two! :P";
            break;
          case 'w':
            $lol = "you guessed one !";
            break;
          case 'y':
            $lol = "you guessed one !";
            break;
          case 'u':
            $lol = "you guessed one !";
            break;
          case 'c':
            $lol = "you guessed one !";
            break;
          case 'a':
            $lol = "you guessed one !";
            break;
          case 'n':
            $lol = "you guessed one !";
            break;
          case '!':
            $lol = "you guessed the last one ! :P";
            break;
          case 'iknowyoucan!':
            $lol = "Ahh Damn !! you found it :(";
            break;
          default:
            $lol = "Hahaha. It's fun to watch you guessing the password!! ;)";
          }
        }
  }

}

function sanitize($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Guess me :P</title>
		<style>
		input{
			display: block;
			margin-top: 10px;
			font-size: larger;
		}
	</style>
</head>
<body>
<div style="position: absolute;margin: auto;top: 0px;bottom: 0px;left: 0px;right: 0px; width: 260px;height: 50px;">
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
	<input type="password" name="passwd" placeholder="password">
	<input type="submit" value="Guess me !" name="">
</form>
  <p id="error"><a href="login.php" >Login in to get the flag</a></p>
	<p id="error"><?php echo $err; ?></p>
	<p id="error"><?php echo $lol; ?></p>

</div>

</body>
</html>




















































































































































































































































































































































































<!-- <label style="color:#FFF;">Guess the password ch4r one by one</label> -->
