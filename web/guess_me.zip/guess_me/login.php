
<?php

$username = $password = $status = $lol = "";
$err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if( empty($_POST["uname"]) || empty($_POST["passwd"])  ){
      $err = "<br /><br />Error : All fields are mandatory";
  }else{
      $username = sanitize($_POST["uname"]);
      $password = sanitize($_POST["passwd"]);
      $status = 1;


  }

   if($status == 1){
    if($username == 'xiomara' and $password == 'iknowyoucan!'){
      if(!session_id()){
        session_start();
      }
      $_SESSION["login_status"] = true;
      header("location: flag.php");
      die();
    }else{
      $err = "<br /><br />Error.Wrong credentials";
    }
  }
}

function sanitize($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Login into get the flag</title>
	<style>
		input{
			display: block;
			margin-top: 10px;
			font-size: larger;
		}
	</style>
</head>
<body>
<div style="position: absolute;margin: auto;top: 0px;bottom: 30px;left: 0px;right: 0px;width:260px;height: 50px;align-items: center;">
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST" style="position: relative;text-align: center;">
	<input type="text" name="uname" placeholder="xiomara">
	<input type="password" name="passwd">
	<input type="submit" value="Get the flag">
</form>
	<p id="error"><?php echo $err; ?></p>
  <p id="error"><?php echo $lol; ?></p>

</div>


</body>
</html>
