<?php

if (!session_id()){
  session_start();
}

if (!$_SESSION['login_status']){
    header("Location:login.php");
    die();
}
echo "You got it.. xiomara{175_ju57_4_51mpl3_0n3}";
?>
