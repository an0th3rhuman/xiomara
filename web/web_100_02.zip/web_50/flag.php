<?php

if (!session_id()){
  session_start();
}

if (!$_SESSION['login_status']){
    header("Location:login.php");
    die();
}
echo "You got it.. xiomara{its_just_a_simple_one}";
?>
