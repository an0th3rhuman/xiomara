
<?php

$username = $password = $status = $lol = "";
$err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if( empty($_POST["uname"]) || empty($_POST["passwd"])  ){
      $err = "<br /><br />Error : All fields are mandatory";
  }else{
      $username = sanitize($_POST["uname"]);
      $user_pass = sanitize($_POST["passwd"]);
      $status = 1;

      if($status == 1){
        switch($user_pass){
          case 'i':
            $lol = "you guessed one !";
            break;
          case 'k':
            $lol = "you guessed one !";
            break;
          case 'n':
            $lol = "you guessed one !";
            break;
          case 'o':
            $lol = "You guessed one or may be two! :P";
            break;
          case 'w':
            $lol = "you guessed one !";
            break;
          case 'y':
            $lol = "you guessed one !";
            break;
          case 'u':
            $lol = "you guessed one !";
            break;
          case 'c':
            $lol = "you guessed one !";
            break;
          case 'a':
            $lol = "you guessed one !";
            break;
          case 'n':
            $lol = "you guessed one !";
            break;
          case '!':
            $lol = "you guessed the last one ! :P";
            break;
          default:
            $lol = "Hahaha. It's fun to watch you guessing the password!! ;)";
          }
        }
  }

}

function sanitize($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<html>
<head>
</head>
  <title>Web_50</title>
<body>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
    Username<input type="text" name="uname" placeholder="xiomara" /><br/>
    Password<input type="password" name="passwd" /><br />
    <input type="submit" value="Get the flag" /><br />
    <a href='login.php'>Click here to login</a>
    <label style="color:#FFF;">Guess the password one by one !!!</label>
    <?php echo $err;   ?>
    <?php echo '<br />'.$lol; ?>

  </form>

</body>
</html>
