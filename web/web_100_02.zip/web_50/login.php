
<?php

$username = $password = $status = $lol = "";
$err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if( empty($_POST["uname"]) || empty($_POST["passwd"])  ){
      $err = "<br /><br />Error : All fields are mandatory";
  }else{
      $username = sanitize($_POST["uname"]);
      $password = sanitize($_POST["passwd"]);
      $status = 1;


  }

   if($status == 1){
    if($username == 'xiomara' and $password == 'iknowyoucan!'){
      if(!session_id()){
        session_start();
      }
      $_SESSION["login_status"] = true;
      header("location: flag.php");
      die();
    }else{
      $err = "<br /><br />Error.Wrong credentials";
    }
  }
}

function sanitize($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<html>
<head>
</head>
  <title>Web_50</title>
<body>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
    Username<input type="text" name="uname" placeholder="xiomara" /><br/>
    Password<input type="password" name="passwd" /><br />
    <input type="submit" value="Get the flag" />
    <?php echo $err;   ?>
    <?php echo '<br />'.$lol; ?>
  </form>

</body>
</html>
