function Login(){
	
	var username=document.login.username.value;
	var password=document.login.password.value;
         
       
    
	
	if (password == "53cure" && username=="@nokh@") {
	    alert("Awesome!");
             window.open("secureflag.html");
	} else { 
	    alert("Oh swap!You are close. Why cant you try again?");
              
	}
}
