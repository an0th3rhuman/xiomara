<?php 
//$allow = array("31.170.165.132"); //allowed IPs if xiomara has multiple server
$allow = "31.170.165.132"; //if xiomara has single server

		//Just get the headers if we can or else use the SERVER global
		if ( function_exists( 'apache_request_headers' ) ) {
			$headers = apache_request_headers();
		} else {
			$headers = $_SERVER;
		}
		//Get the forwarded IP if it exists
		if ( array_key_exists( 'X-Forwarded-For', $headers ) && filter_var( $headers['X-Forwarded-For'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			$the_ip = $headers['X-Forwarded-For'];
		} elseif ( array_key_exists( 'HTTP_X_FORWARDED_FOR', $headers ) && filter_var( $headers['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 )
		) {
			$the_ip = $headers['HTTP_X_FORWARDED_FOR'];
		} else {
			
			$the_ip = filter_var( $_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 );
		}

                echo "Your ip is ";
                echo $the_ip;

               if ($the_ip!=$allow)
                {

            echo "Your IP is not in whitelist. Your permission is denied to read my story.<br><br>";
            
            
      
       

     

    exit();}
	

    echo "Welcome mafiakid!";
  header('Location: http://www.web100.esy.es/8226ceffa74f527226c39f26ed6b0b88/');//to redirect if the ip is correct.. Not the same domain name given in header should be used

 ?>
