from os import listdir

del __builtins__.__dict__['__import__']
del __builtins__.__dict__['reload']
del __builtins__.__dict__['compile']

print "Welcome to Book_my_show.com !"



choices = (
  ("Star Wars: The Force Awakens ",200, "caburrito.txt"),
  ("Avengers: Age of Ultron      ", 100, "beefchow.txt"),
  ("Minions                      ",50 , "beefchow.txt"),
  ("American Pie                 ",500, "no description"),
  ("Life of Pie                  ", 150, "no description"),
  # ...
)

def show_menu():
  print "\n----------Movie----------------------Rs-----------------------------\n"
  for i in xrange(len(choices)):
    print "[% 2d ]  %s $%d" % (i, choices[i][0],choices[i][1])
  print "\n--------------------------------------------------------------------\n"

def print_desc(val):
  print "[+] You have choosen :"+str(choice)
  print "[+] Your ticket have been successfully booked !"
  print "Thank u for using our app !"
while True:
  print "\n"
  print "Select your movie you want !!"
  show_menu()
  choice = int(input(">>"))
  print_desc(choice)
