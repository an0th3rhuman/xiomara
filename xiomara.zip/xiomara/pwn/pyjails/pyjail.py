#!/usr/bin/env python2
import logging as log
import re

log.basicConfig(filename="error.log")
x = None

print """
Welcome to Secure Python Interpreter 
================================================

Rules:
    -Do not import anything
    -No peeking at files!
    -No sharing of flags :)

"""
def filter_cmd(cmd):
   blacklist = re.compile('import|sys|log')
   for word in cmd.split():
     if  blacklist.search(word):
         print "Denied"
         return 0
     else:
         return 1


def main():
   global x
   cmd = raw_input(">>")
   #var = {'x':None}
   if filter_cmd(cmd):
         exec 'y='+cmd #in var
         print y

if __name__ == '__main__':
  while True:
    try:
        main()
    except Exception as ex:
        log.error(str(type(ex)) + str(ex))
        print"Error"
