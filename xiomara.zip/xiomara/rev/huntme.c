#include<stdio.h>
#include <stdlib.h>
#include <sys/ptrace.h>
#include<string.h>
#include<signal.h>
#include <unistd.h>

void generate_flag() __attribute__ ((destructor));

unsigned int no_gdb = 1;
static void handler(int signum){no_gdb = 1;}
char s[] = "flag{this_is_a_fake_flag_dig_deeper_:(}";

int gdb_sigtrap()
  {

    no_gdb = 0;
    signal(SIGTRAP, handler);
    raise(SIGTRAP);
    signal(SIGTRAP, SIG_IGN);
    return no_gdb;

  }

int gdb_ptrace(){
    if(ptrace(PTRACE_TRACEME, 0, 0, 0) == -1)
        return 1;
    ptrace(PTRACE_DETACH, 0, 0, 0);
    return 0;
}

void encrypt(char s[],int n)
{    int i ;
     int randnum ;
     randnum = rand() % 10 ;
     for(i=0;i<38;i++)
         {			
            s[i]=s[i]+randnum;
         }
    write(0,s,39);
    puts("\n");       
}

void generate_flag()
{  
   int i; 
   char flag[50];
   int exor[] = { 0x1e, 0x5, 0xe, 0xa, 0x1a, 0x6, 0x9, 0x12, 0xa, 0x6f, 0x30, 0x2c, 0x6b, 0x13, 0x1a, 0x39, 0x55, 0x34, 0x5c, 0x2d, 0x3, 0x58, 0x56, 0x38, 0x3d, 0x54, 0x1c, 0x29, 0x68, 0x1d, 0x3a, 0xd, 0x25, 0xb, 0x45, 0x1a, 0x68, 0x9, 0x0 };
    if(gdb_ptrace())
     {
        printf("Are u kidding me \n");
        printf("Running a ptrace wont give u flag ...\n");
        exit(0);

     }
      else
      {
          for(i=0;i<39;i++)
          { 
              flag[i] = s[i] ^ exor[i] ; 
           }
           //printf("%s\n",flag);
           encrypt(flag,39);
      }
}



void  detect_gdb()
{
      if(!gdb_sigtrap())
      {
        printf(" BOOOooooooooMMMMM \n");
        printf(" No Breakpoints any more !!!!!\n");
      }
}



int main()
{
     detect_gdb();
     printf("your flag is :\n");
}



